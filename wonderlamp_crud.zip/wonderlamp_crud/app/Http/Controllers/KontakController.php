<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Kontak;
class KontakController extends Controller
{
    public function index()
    {
        return view('kontak');
    }
    public function store(Request $request)
    {
        $kontak = new Kontak;
        $kontak->nama = $request->nama;
        $kontak->no_hp = $request->no_hp;
        $kontak->email = $request->email;
        $kontak->pesan = $request->pesan;
        $kontak->save();
        return redirect('kontak')->with('status', 'Berhasil terkirim');
    }
}

