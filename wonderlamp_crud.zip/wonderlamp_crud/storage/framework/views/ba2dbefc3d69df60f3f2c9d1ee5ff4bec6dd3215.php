

<?php $__env->startSection('title'); ?>
<title>Pulau Pahawang</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('carosel'); ?>
<div class="img">
    <img src="https://ksmtour.com/media/images/articles11/pulau-pahawang-lampung.jpg" alt="" srcset="">
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('detail'); ?>
<div class="description">
    Pulau Pahawang terkenal dengan keindahan pantai dan bawah lautnya. <span id="dots">...</span>

    <span id="more">
        Sudah banyak yang mengakui pesonanya, baik wisatawan nusantara maupun wisatawan lokal Lampung
        Pulau Pahawang masuk wilayah Kecamatan Punduh Pidada, Kabupaten Pesawaran, Provinsi Lampung. Tepatnya berada di Teluk Lampung.

        Untuk bisa sampai di pulau, tidak memerlukan waktu berhari-hari. Sebab jaraknya tidak terlalu jauh dari Kota Bandar Lampung. Kalau lancar, hanya membutuhkan waktu sekitar 2 jam untuk tiba di pulau.
        Banyak tidak mengetahui kalau Teluk Lampung memiliki banyak jenis ikan badut (clownfish). Sekali snorkeling, kalau beruntung, bisa menjumpai beberapa jenis ikan badut.
        Ada ikan badut bewarna putih dengan corak bewarna oranye. Seperti yang pernah kamu tonton di film “Finding Nemo”. Juga ada clownfish warna dan corak lain di sini.
    </span>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('content.contentmain', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Zaki\Telkom\Tahun 3\Semester 6\ABP\Tubes\Github Wonderlamp\abp-wonderlamp\wonderlamp\resources\views/content/pulaupahawang.blade.php ENDPATH**/ ?>